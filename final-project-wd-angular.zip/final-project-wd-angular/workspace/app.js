var app = angular.module("eventsMap", []);
